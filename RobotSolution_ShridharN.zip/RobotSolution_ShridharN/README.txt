1) Please use following command to execute the program.And use Java 8 for executing the program.
	java -jar robot-1.0-jar-with-dependencies.jar
2) The solution assumes that the robot cannot go beyond x=4,y=4 coordinates.
3) The BYE command can be used to exit the program.
4) Below are few sample data tests which can used for testing.

Test data 1:
PLACE 2,2,NORTH
MOVE
RIGHT
REPORT

Output: 2,3,EAST


Test data 2: (NO OUTPUT,AS ROBOT WILL FALL FOR BELOW COORDINATES.)
PLACE 5,5,EAST
REPORT


Test data 3:
PLACE 4,4,SOUTH
MOVE
MOVE
LEFT
REPORT

Output: 4,2,EAST